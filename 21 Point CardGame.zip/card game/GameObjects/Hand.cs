﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Mingqi Ji n10362193
/// Zihao Zhang n10181385
/// </summary>
namespace GameObjects
{
    /// <summary>
    /// Create list of cards that contains all functionalities represents user's hand and 'computer's hand.
    /// </summary>
    public class Hand : IEnumerable
    {
        //create a new list as player's hand.
        private List<Card> _hand;

        /// <summary>
        /// setting the count property.
        /// </summary>
        public int Count {
            get {
                return _hand.Count;
            }
        }
        /// <summary>
        /// create a new empty hand. 
        /// </summary>
        public Hand() {
            _hand = new List<Card>();
        }
        /// <summary>
        /// the method that put cards into previous empty hand.
        /// </summary>
        /// <param name="cards">a list of card. </param>
        public Hand(List<Card> cards) {
            _hand = cards;           
        }
        /// <summary>
        /// the method that return the card at the given position in the hand.
        /// </summary>
        /// <param name="index">the card's position.</param>
        /// <returns>return the card in the specific position.  </returns>
        public Card GetCard(int index)
        {
            return _hand[index];
        }
        /// <summary>
        /// the method that add cards to player's hand. 
        /// </summary>
        /// <param name="card">the card with suit and facevalue.</param>
        public void AddCard(Card card) {
            _hand.Add(card);
        }
        /// <summary>
        /// the method to check if the card is in the hand list.
        /// </summary>
        /// <param name="card">the card with suit and facevalue.</param>
        /// <returns>return true if the card is in the hand list.
        /// return false if the card is not in the hand list. </returns>
        public bool ContainsCard(Card card) {
            return _hand.Contains(card);
        }
        /// <summary>
        /// the method that remove card from hand list.
        /// </summary>
        /// <param name="card">the card with suit and facevalue.</param>
        /// <returns>return the hand list after removing cards.</returns>
        public bool RemoveCard(Card card) {
            return _hand.Remove(card);
        }
        /// <summary>
        /// the method that remove cards at specific position. 
        /// </summary>
        /// <param name="index">the position of the card. </param>
        /// <returns>return the hand list fater removing cards.</returns>
        public bool RemoveCardAt(int index) {
            return _hand.Remove(_hand[index]);
        }
        /// <summary>
        /// the method that sort the hand list.
        /// </summary>
        public void SortHand() {           
            _hand.Sort();
        }
        /// <summary>
        /// the method that allows code in other classes to use foreach with this class.
        /// </summary>
        /// <returns>the hand list.</returns>
        public IEnumerator GetEnumerator()
        {
            return _hand.GetEnumerator();
        }
    }
    }
