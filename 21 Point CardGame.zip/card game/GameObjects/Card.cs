﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Mingqi Ji n10362193
/// Zihao Zhang n10181385
/// </summary>
namespace GameObjects {
    public enum Suit { Clubs, Diamonds, Hearts, Spades }
    public enum FaceValue
    {
        Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine,
        Ten, Jack, Queen, King
    }

    /// <summary>
    /// Create a collection of cards, contains all functionalities that will be used in other parts.
    /// </summary>
    public class Card : IEquatable<Card>, IComparable<Card>
    {
        //Create two new list to store the numbers and capital letters.        
        public  string[] facevaluelist = new string[] {
            "A", "2", "3", "4","5","6","7","8","9","10","J","Q","K"
        };
        public  string[] suitlist = new string[] {
            "C", "D", "H", "S"
        };
        private Suit _suit;
        private FaceValue _facevalue;
        /// <summary>
        /// setting the Facevalue property
        /// </summary>
        public FaceValue FaceValue{
            get {
                return _facevalue;                
                    }            
        }
        /// <summary>
        /// setting the Suit property
        /// </summary>
        public Suit Suit { 
            get {
                return _suit;
            }
        }

        /// <summary>
        /// Create the card method that includes suit and facevalue
        /// </summary>
        /// <param name="suit">represent card's suit</param>
        /// <param name="faceValue">represent card's facevalue</param>
        public Card(Suit suit, FaceValue faceValue) {
            _facevalue = faceValue;
            _suit = suit;                    
        }
        /// <summary>
        /// create the method that can judge if the current card equals to previous one
        /// </summary>
        /// <param name="card">use card as the parameter to judge if the suit and facevalue
        /// are equal to previous one</param>
        /// <returns>if two cards have the same suit and value, return true</returns>
        public bool Equals(Card card) {
            return this.FaceValue == card.FaceValue && this.Suit == card.Suit;
        }
        /// <summary>
        /// create the method that change a card's facevalue and suit to string  
        /// </summary>
        /// <returns>return the abbreviation of the card's suit and facevalue </returns>
        public override string ToString()
        {
            return facevaluelist[(int)this.FaceValue] + suitlist[(int)this.Suit];
        }
        /// <summary>
        /// create the method that compare two card's suit and facevalue
        /// </summary>
        /// <param name="card">use the card as parameter to compare to another card</param>
        /// <returns>if return 0, the current card occurs in the same 
        /// position with as given card. If return 1, the current card
        /// is sorted after the given card. If return -1, the current card is sorted 
        /// before the given card</returns>
        public int CompareTo(Card card)
        {
            if (this.Suit > card.Suit) { return 1; }
            else if (this.Suit < card.Suit) { return -1; }
            else
            {
                if (this.FaceValue > card.FaceValue) { return 1; }
                else if (this.FaceValue < card.FaceValue) { return -1; }
                else
                {
                    return 0;
                }

            }
           
    }
    }
}
