﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Mingqi Ji n10362193
/// Zihao Zhang n10181385
/// </summary>
namespace GameObjects
{/// <summary>
/// Create a card pile that contains 52 cards, and functionalities for using card pile.
/// </summary>
    public class CardPile
    {
        //setting integers to avoid magic numbers
        private const int CARD_NUMBER = 52;
        private const int NUM_SUITS = 4;
        private const int NUM_FACEVALUES = 13;
        //create a new list to store cards
        private List<Card> _pile = new List<Card>();
        private Random random = new Random();
        /// <summary>
        /// create count property
        /// </summary>
        public int Count {
            get {
                return _pile.Count;
            }
        }
        /// <summary>
        /// this is the method that create a new card pile 
        /// </summary>
        /// <param name="generate">If the parameter is true, it will 
        /// create a new card pile with 52 cards. If the parameter is false, it will
        /// create an empty card pile. By defult, it will 
        /// create an empty card pile.</param>
        public CardPile(bool generate = false) {
            if (generate == true) {
                for (int suit = 0; suit < NUM_SUITS; suit++) {
                    for (int facevalue = 0; facevalue < NUM_FACEVALUES; facevalue++) {
                        _pile.Add(new Card ((Suit)suit, (FaceValue)facevalue));
                    }
                }
            }
        }
        /// <summary>
        /// the method that can add a card to card pile 
        /// </summary>
        /// <param name="card">the card parameter has suit and facevalue</param>
        public void AddCard(Card card) {
            _pile.Add(card);
        }
        /// <summary>
        /// the method that count how many cards in the card pile 
        /// </summary>
        /// <returns>return how many cards in the card pile</returns>
        public  int GetCount() {
            return _pile.Count();
        }
        /// <summary>
        /// the method that can get the last card in the card pile 
        /// </summary>
        /// <returns>return the last card(suit and facevalue)</returns>
        public Card GetLastCardInPile() {
            if (this.Count == 0)
            {
                return null;
            }
            else
            {
                return _pile[_pile.Count - 1];
            }
        }
        /// <summary>
        /// the method that shuffle the card pile
        /// </summary>
        public void ShufflePile(int a= CARD_NUMBER) {
            int number;

            
            List<Card> pile = new List<Card>();
            

            List<int> listNumbers = new List<int>();
            listNumbers.Clear();
            for (int i = 0; i < a; i++)
            {
                do
                {
                    number = random.Next(0, a);

                } while (listNumbers.Contains(number));
                listNumbers.Add(number);
                Card card = _pile[listNumbers[i]];
                pile.Add(card);
            }
            _pile = pile;

        }
            
        /// <summary>
        /// the method that player pick up one card form the card pile 
        /// </summary>
        /// <returns>return the first card of the card pile</returns>
        public Card DealOneCard() {
            Card card = _pile[0];
             _pile.RemoveAt(0);
            return card;
        }
        /// <summary>
        /// the method that remove cards from card pile to player's hand 
        /// </summary>
        /// <param name="number">the number of how many cards does player pick up</param>
        /// <returns>return a new pile list of player's hand cards</returns>
        public List<Card> DealCards(int number) {
            List<Card> pile = new List<Card>();
            for (int card = 0; card < number; card++) {
                pile.Add(_pile[0]);
                _pile.RemoveAt(0);
            }
            return pile;
        }

    }
}
