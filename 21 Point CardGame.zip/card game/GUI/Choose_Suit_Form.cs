﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
/// <summary>
/// Mingqi Ji n10362193
/// Zihao Zhang n10181385
/// </summary>
{
    /// <summary>
    /// Create a window for user to choose a suit
    /// </summary>
    public partial class Choose_Suit_Form : Form
    {
        /// <summary>
        /// string for store the chosen suit
        /// </summary>
        public string chosenSuit { get; private set; }

        /// <summary>
        /// Initialize the form
        /// </summary>
        public Choose_Suit_Form()
        {
            InitializeComponent();
        }
        /// <summary>
        /// the method that close the current window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPlayCard_Click(object sender, EventArgs e)
        {         
            this.Close();
        }
        /// <summary>
        /// the method that change the text in the main window's lable
        /// what suit user choose. 
        /// </summary>
        private void rdochecking_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoClubes.Checked) {
                chosenSuit = rdoClubes.Text;
                btnPlayCard.Enabled = true;
            }
            else if (rdoDiamonds.Checked)
            {
                chosenSuit = rdoDiamonds.Text;
                btnPlayCard.Enabled = true;
            }
            else if (rdoHearts.Checked)
            {
                chosenSuit = rdoHearts.Text;
                btnPlayCard.Enabled = true;
            }
            else if (rdoSpades.Checked)
            {
                chosenSuit = rdoSpades.Text;
                btnPlayCard.Enabled = true;
            }
        }
    }
}
