﻿namespace GUI
{
    partial class Choose_Suit_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Choose_Suit_Form));
            this.lblInstruction = new System.Windows.Forms.Label();
            this.grpChooseSuit = new System.Windows.Forms.GroupBox();
            this.rdoSpades = new System.Windows.Forms.RadioButton();
            this.rdoHearts = new System.Windows.Forms.RadioButton();
            this.rdoDiamonds = new System.Windows.Forms.RadioButton();
            this.rdoClubes = new System.Windows.Forms.RadioButton();
            this.btnPlayCard = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.grpChooseSuit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstruction.Location = new System.Drawing.Point(44, 51);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(271, 46);
            this.lblInstruction.TabIndex = 0;
            this.lblInstruction.Text = "    You chose an Eight! \r\nYou get to choose the Suit.\r\n";
            // 
            // grpChooseSuit
            // 
            this.grpChooseSuit.Controls.Add(this.pictureBox4);
            this.grpChooseSuit.Controls.Add(this.pictureBox3);
            this.grpChooseSuit.Controls.Add(this.pictureBox2);
            this.grpChooseSuit.Controls.Add(this.pictureBox1);
            this.grpChooseSuit.Controls.Add(this.rdoSpades);
            this.grpChooseSuit.Controls.Add(this.rdoHearts);
            this.grpChooseSuit.Controls.Add(this.rdoDiamonds);
            this.grpChooseSuit.Controls.Add(this.rdoClubes);
            this.grpChooseSuit.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpChooseSuit.Location = new System.Drawing.Point(71, 120);
            this.grpChooseSuit.Name = "grpChooseSuit";
            this.grpChooseSuit.Size = new System.Drawing.Size(200, 181);
            this.grpChooseSuit.TabIndex = 1;
            this.grpChooseSuit.TabStop = false;
            this.grpChooseSuit.Text = "Choose a Suit";
            // 
            // rdoSpades
            // 
            this.rdoSpades.AutoSize = true;
            this.rdoSpades.Location = new System.Drawing.Point(61, 149);
            this.rdoSpades.Name = "rdoSpades";
            this.rdoSpades.Size = new System.Drawing.Size(80, 22);
            this.rdoSpades.TabIndex = 5;
            this.rdoSpades.Text = "Spades";
            this.rdoSpades.UseVisualStyleBackColor = true;
            this.rdoSpades.CheckedChanged += new System.EventHandler(this.rdochecking_CheckedChanged);
            // 
            // rdoHearts
            // 
            this.rdoHearts.AutoSize = true;
            this.rdoHearts.Location = new System.Drawing.Point(61, 108);
            this.rdoHearts.Name = "rdoHearts";
            this.rdoHearts.Size = new System.Drawing.Size(75, 22);
            this.rdoHearts.TabIndex = 4;
            this.rdoHearts.Text = "Hearts";
            this.rdoHearts.UseVisualStyleBackColor = true;
            this.rdoHearts.CheckedChanged += new System.EventHandler(this.rdochecking_CheckedChanged);
            // 
            // rdoDiamonds
            // 
            this.rdoDiamonds.AutoSize = true;
            this.rdoDiamonds.Location = new System.Drawing.Point(61, 65);
            this.rdoDiamonds.Name = "rdoDiamonds";
            this.rdoDiamonds.Size = new System.Drawing.Size(100, 22);
            this.rdoDiamonds.TabIndex = 3;
            this.rdoDiamonds.Text = "Diamonds";
            this.rdoDiamonds.UseVisualStyleBackColor = true;
            this.rdoDiamonds.CheckedChanged += new System.EventHandler(this.rdochecking_CheckedChanged);
            // 
            // rdoClubes
            // 
            this.rdoClubes.AutoSize = true;
            this.rdoClubes.Location = new System.Drawing.Point(61, 25);
            this.rdoClubes.Name = "rdoClubes";
            this.rdoClubes.Size = new System.Drawing.Size(75, 22);
            this.rdoClubes.TabIndex = 2;
            this.rdoClubes.Text = "Clubes";
            this.rdoClubes.UseVisualStyleBackColor = true;
            this.rdoClubes.CheckedChanged += new System.EventHandler(this.rdochecking_CheckedChanged);
            // 
            // btnPlayCard
            // 
            this.btnPlayCard.Enabled = false;
            this.btnPlayCard.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayCard.Location = new System.Drawing.Point(108, 324);
            this.btnPlayCard.Name = "btnPlayCard";
            this.btnPlayCard.Size = new System.Drawing.Size(119, 42);
            this.btnPlayCard.TabIndex = 6;
            this.btnPlayCard.Text = "Play card";
            this.btnPlayCard.UseVisualStyleBackColor = true;
            this.btnPlayCard.Click += new System.EventHandler(this.btnPlayCard_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(19, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(19, 58);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(19, 99);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 34);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(19, 139);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(29, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // Choose_Suit_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 403);
            this.ControlBox = false;
            this.Controls.Add(this.btnPlayCard);
            this.Controls.Add(this.grpChooseSuit);
            this.Controls.Add(this.lblInstruction);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Choose_Suit_Form";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Choose a Suit";
            this.TopMost = true;
            this.grpChooseSuit.ResumeLayout(false);
            this.grpChooseSuit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.GroupBox grpChooseSuit;
        private System.Windows.Forms.RadioButton rdoSpades;
        private System.Windows.Forms.RadioButton rdoHearts;
        private System.Windows.Forms.RadioButton rdoDiamonds;
        private System.Windows.Forms.RadioButton rdoClubes;
        private System.Windows.Forms.Button btnPlayCard;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}