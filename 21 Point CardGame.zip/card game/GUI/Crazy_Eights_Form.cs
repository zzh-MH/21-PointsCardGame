﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CrazyEightsTests;
using GameObjects;
using Games;
/// <summary>
/// Mingqi Ji n10362193
/// Zihao Zhang n10181385
/// </summary>
namespace GUI {
    

    /// <summary>
    /// Create main window for Crazy Eights
    /// </summary>
    public partial class Crazy_Eights_Form : Form {
        /// <summary>
        /// initialize the form
        /// </summary>       
        public Crazy_Eights_Form() {
            InitializeComponent();            
            picDrawPile.Image = Images.GetBackOfCardImage();   
            
        }
        //setting some variables to avoid magic numbers
        private const int Clubes = 0;        private const int Diamonds = 1;        private const int Hearts = 2;        private const int Spades = 3;        private const int Empty = -1;        /// <summary>
        /// method for display hand cards
        /// </summary>
        /// <param name="hand"> hand list contain cards </param>
        /// <param name="panel"> display user's cards</param>
        private void DisplayHand(Hand hand, TableLayoutPanel panel)
        {
            // remove any previous card images
            panel.Controls.Clear();
            // repeat for each card in the hand
            for (int count = 0; count < hand.Count; count++)
            {
                // add a picture box to the panel with the appropriate image
                PictureBox picCard = new PictureBox();
                picCard.SizeMode = PictureBoxSizeMode.AutoSize;
                picCard.Image = Images.GetCardImage(hand.GetCard(count));
                panel.Controls.Add(picCard, count, 0);
                // add an event handler if it is being added to the user’s panel
                if (panel == tblUserHand)
                {
                    picCard.Click += new System.EventHandler(this.picPlayCard_Click);
                }
            }
            panel.Refresh();
        }
        /// <summary>
        /// set a method that update the user's, discard pile and computer's hand
        /// </summary>
        public void UpdateGUI()
        {
            DisplayHand(CrazyEights.UserHand, tblUserHand);            DisplayHand(CrazyEights.ComputerHand, tblComputerHand);            // TODO: Handle empty discard pile (TopDiscard is null)            if (CrazyEights.TopDiscard == null)
            {
                picDiscardPile.Image = null;
            }            else
            {
                picDiscardPile.Image = Images.GetCardImage(CrazyEights.TopDiscard);
            }            picDiscardPile.Refresh();
        }

        /// <summary>
        /// the method that user can play the card 
        /// </summary>
        public void picPlayCard_Click(object sender, EventArgs e)
        {
            // get the picturebox that was clicked
            PictureBox picCard = (PictureBox)sender;
            // determine the position of the picturebox that was clicked
            int columnNum = ((TableLayoutPanel)((Control)sender).Parent).GetPositionFromControl(picCard).Column;
            CrazyEights.ActionResult result = CrazyEights.UserPlayCard(columnNum);
            UpdateInstructions("Your Turn!");
            UpdateGUI();
            //all user's action results
            switch (result)
            {
                case CrazyEights.ActionResult.ValidPlay:
                    UpdateInstructions("You played a card", true);
                    ComputerTurn();

                    break;
                case CrazyEights.ActionResult.DrewAndNoMovePossible:
                    UpdateInstructions("No possible moves\n Computer Turn!", true);
                    ComputerTurn();
                    break;
                case CrazyEights.ActionResult.SuitRequired:
                    Suit suit = GetSuit();
                    CrazyEights.UserPlayCard(columnNum, suit);
                    UpdateGUI();
                    ComputerTurn();
                    break;
                case CrazyEights.ActionResult.InvalidPlayAndMustDraw:
                    UpdateInstructions("You must draw a card", true);
                    break;
               
                case CrazyEights.ActionResult.ValidPlayAndExtraTurn:
                    UpdateInstructions("User Turn!", true);
                    break;
                case CrazyEights.ActionResult.InvalidPlay:
                    UpdateInstructions("Cannot play this card", true);
                    break;
                
                case CrazyEights.ActionResult.WinningPlay:
                    btnEndGame.Enabled = false;
                    tblUserHand.Enabled = false;
                    picDrawPile.Enabled = false;
                    btnSortHand.Enabled = false;
                    btnDeal.Enabled = true;
                    UpdateInstructions("You won!");
                    break;
                
            }

        }
        /// <summary>
        /// setting functions in the drawpile pictrue that user can draw cards
        /// </summary>
        private void picDrawPile_Click(object sender, EventArgs e)
        {
            picDrawPile.Image = Images.GetBackOfCardImage();            CrazyEights.ActionResult result;            result = CrazyEights.UserDrawCard();
            UpdateGUI();
            switch (result)
            {              
                case CrazyEights.ActionResult.DrewPlayableCard:
                    btnSortHand.Enabled = true;
                    UpdateInstructions("Your drew a card");
                    break;
                case CrazyEights.ActionResult.CannotDraw:
                    UpdateInstructions("Cannot draw a card");
                    break;
                case CrazyEights.ActionResult.FlippedDeck:
                    UpdateInstructions("Deck flipping!", true);
                    UpdateInstructions("Deck flipped!", true);
                    picDrawPile.Image = Images.GetBackOfCardImage();
                    break;
                case CrazyEights.ActionResult.DrewAndNoMovePossible:
                    UpdateInstructions("You drew a card!", true);
                    UpdateInstructions("Your hand is full!", true);
                    UpdateInstructions("No cards can play!", true);
                    UpdateInstructions("Computer Turn!", true);
                    ComputerTurn();
                    break;
                case CrazyEights.ActionResult.DrewAndResetPiles:
                    UpdateInstructions("You drew a card!",true);
                    UpdateInstructions("Your hand is full!", true);                    
                    UpdateInstructions("No cards can play!", true);
                    UpdateInstructions("flipping deck!", true);
                    ComputerTurn();
                    break;
            }
        }

        /// <summary>
        /// setting functions in the deal button that user can start the game 
        /// </summary>
        private void btnDeal_Click(object sender, EventArgs e)
        {
            tblUserHand.Enabled = true;
            picDrawPile.Enabled = true;
            btnEndGame.Enabled = true;
            btnSortHand.Enabled = true;
            btnDeal.Enabled = false;
            CrazyEights.StartGame();            
            DisplayHand(CrazyEights.UserHand, tblUserHand);            DisplayHand(CrazyEights.ComputerHand, tblComputerHand);            picDiscardPile.Image = Images.GetCardImage(CrazyEights.TopDiscard);            UpdateInstructions("Your Turn!");
        }

        /// <summary>
        /// the method that can uodate the label information
        /// </summary>
        /// <param name="message"> change the instruction's label</param>
        /// <param name="wait"> if wait is true, sleep a short time</param>
        private void UpdateInstructions(string message, bool wait = false)
        {
            lblInstruction.Text = message;
            lblInstruction.Refresh();
            if (wait)
            {
                System.Threading.Thread.Sleep(1000);
            }
        }

        /// <summary>
        ///  quit the game
        /// </summary>        
        private void btnEndGame_Click(object sender, EventArgs e)
        {
            CrazyEights.EndGame();
            tblUserHand.Enabled = false;
            picDrawPile.Enabled = false;
            btnSortHand.Enabled = false;
            btnDeal.Enabled = true;
            UpdateInstructions("Game Stopped"); 
        }
        /// <summary>
        /// the method that can sort user's hand
        /// </summary>
        private void btnSortHand_Click(object sender, EventArgs e)
        {
            btnSortHand.Enabled = false;
            CrazyEights.SortUserHand();
            UpdateInstructions("Hand Sorted!",true);
            UpdateInstructions("Your Turn!");
            UpdateGUI();
        }       
        /// <summary>
        /// create a method that generates computer to play the game
        /// </summary>
        public void ComputerTurn()
        {
            while (!CrazyEights.IsUserTurn && CrazyEights.IsPlaying)
            {
                UpdateInstructions("Computer Turn!", true);
                CrazyEights.ActionResult result = CrazyEights.ComputerAction();
                UpdateGUI();
                //all computer's action results
                switch (result)
                {
                    case CrazyEights.ActionResult.DrewPlayableCard:
                        UpdateInstructions("Computer drew a card!", true);
                        break;
                    case CrazyEights.ActionResult.DrewUnplayableCard:
                        UpdateInstructions("Computer drew a card!", true);
                        break;
                    case CrazyEights.ActionResult.DrewAndNoMovePossible:
                        UpdateInstructions("Computer drew a card!", true);
                        UpdateInstructions("Computer's hand is full!", true);
                        UpdateInstructions("No move possible!", true);
                        UpdateInstructions("User's turn!", true);
                        break;
                    case CrazyEights.ActionResult.DrewAndResetPiles:
                        UpdateInstructions("Computer drew a card!", true);
                        UpdateInstructions("Nobody can play!", true);
                        UpdateInstructions("Shuffle pile!", true);
                        UpdateInstructions("User's turn!",true);
                        break;
                    
                    case CrazyEights.ActionResult.FlippedDeck:
                        UpdateInstructions("Computer flipping deck!", true);
                        break;
                    case CrazyEights.ActionResult.ValidPlay:
                        UpdateInstructions("Computer played a card!", true);
                        UpdateInstructions("Your Turn!");
                        break;
                    case CrazyEights.ActionResult.WinningPlay:
                        UpdateInstructions("Computer won!");
                        btnEndGame.Enabled = false;
                        tblUserHand.Enabled = false;
                        picDrawPile.Enabled = false;
                        btnSortHand.Enabled = false;
                        btnDeal.Enabled = true;
                        break;
                    case CrazyEights.ActionResult.ValidPlayAndExtraTurn:
                        UpdateInstructions("Computer Turn!", true);
                        break;
                    case CrazyEights.ActionResult.ForcelyEnd:
                        UpdateInstructions("User Turn!", true);
                        break;
                }
            }

        }
        /// <summary>
        /// create a method that can get user's choice from choose_suit form
        /// </summary>
        /// <returns></returns>
        public  static Suit GetSuit()
        {
            Choose_Suit_Form suitForm = new Choose_Suit_Form();
            suitForm.ShowDialog();            string choosen = suitForm.chosenSuit;
            int choice = Empty;
            if (choosen.ToLower() == "clubes"){
                choice = Clubes;
            }
            else if (choosen.ToLower() == "diamonds")
            {
                choice = Diamonds;
            }
            else if (choosen.ToLower() == "hearts")
            {
                choice = Hearts;
            }
            else if (choosen.ToLower() == "spades")
            {
                choice = Spades;
            }
            return (Suit)(choice);
        }        
    }
}
