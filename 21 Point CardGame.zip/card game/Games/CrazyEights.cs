﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

using GameObjects;

namespace Games
{
    /// <summary>
    /// this is the method that contains all game logic
    /// </summary>
    public static class CrazyEights
    {
        /// <summary>
        /// create a enum to store all action results 
        /// </summary>
        public enum ActionResult
        {
            /// <summary>
            /// A card was played that won the game
            /// </summary>
            WinningPlay,
            /// <summary>
            /// A valid card was played
            /// </summary>
            ValidPlay,
            /// <summary>
            /// A suit is required to continue play
            /// </summary>
            SuitRequired,
            /// <summary>
            /// Attempted to play an invalid card
            /// </summary>
            InvalidPlay,
            /// <summary>
            /// Attempted to play an invalid card when no cards can be played
            /// </summary>
            InvalidPlayAndMustDraw,
            /// <summary>
            /// A valid card was played, and the other player cannot play
            /// </summary>
            ValidPlayAndExtraTurn,
            /// <summary>
            /// Drew a playable card
            /// </summary>
            DrewPlayableCard,
            /// <summary>
            /// Drew an unplayable card
            /// </summary>
            DrewUnplayableCard,
            /// <summary>
            /// Drew an unplayable card and filled the hand
            /// </summary>
            DrewAndNoMovePossible,
            /// <summary>
            /// Drew an unplayable card and filled the hand, leaving both
            /// players unable to play, so piles were reset so that the
            /// the other player can continue play (rule 9)
            /// </summary>
            DrewAndResetPiles,
            /// <summary>
            /// Attempted to draw a card while moves were still possible
            /// </summary>
            CannotDraw,
            /// <summary>
            /// Flipped the discard pile to use as the new draw pile (rule 10)
            /// </summary>
            FlippedDeck,
            /// <summary>
            /// forcely end user's turn
            /// </summary>
            ForcelyEnd
        }
        //setting some variables to avoid magic numbers
        private const int FullHandCardNum = 13;
        private const int InitialCardNum = 8;
        private const int Empty = -1;

        /// <summary>
        /// set a draw card pile 
        /// </summary>
        private static CardPile _drawPile = new CardPile(true);
        /// <summary>
        /// set a discard pile
        /// </summary>
        private static CardPile _discardPile = new CardPile();
        /// <summary>
        /// set the property that judge the draw card pile is empty or not
        /// </summary>
        public static bool IsDrawPileEmpty
        {
            get
            {
                return _drawPile.Count == 0;
            }
        }
        /// <summary>
        /// set a property that could return the top card in the discard pile
        /// </summary>
        public static Card TopDiscard
        {

            get
            {
                return _discardPile.GetLastCardInPile();
            }
        }
        /// <summary>
        /// set a hand list that represent computer's hand
        /// </summary>
        public static Hand ComputerHand
        {
            get;
            private set;
        }
        /// <summary>
        /// set a hand list that represent user's hand
        /// </summary>
        public static Hand UserHand
        {
            get;
            private set;
        }
        /// <summary>
        /// set a property that judge if it's user's turn or not
        /// </summary>
        public static bool IsUserTurn
        {
            get;
            private set;
        }
        /// <summary>
        /// set a property that judge if the game is playing or not
        /// </summary>
        public static bool IsPlaying
        {
            get;
            private set;
        }
        /// <summary>
        /// set a method that could start the crazy eight game
        /// </summary>
        public static void StartGame()
        {
            IsUserTurn = true;
            IsPlaying = true;
            _discardPile = new CardPile();
            _drawPile = new CardPile(generate: true);
            _drawPile.ShufflePile();
            //give player and computer 8 cards at the beginning 
            UserHand = new Hand();
            for (int count = 0; count < InitialCardNum; count++)
            {
                UserHand.AddCard(_drawPile.DealOneCard());
            }
            //transfer the top card in the card pile to the discard pile
            ComputerHand = new Hand();
            for (int count = 0; count < InitialCardNum; count++)
            {
                ComputerHand.AddCard(_drawPile.DealOneCard());
            }
            _drawPile.DealOneCard();
            _discardPile.AddCard(_drawPile.DealOneCard());
        }
        /// <summary>
        /// the method that could sort user's hand
        /// </summary>
        public static void SortUserHand()
        {
             UserHand.SortHand();
        }
        /// <summary>
        /// this method is used for the test
        /// </summary>
        /// <param name="userHand">user's hand </param>
        /// <param name="computerHand">computer's hand </param>
        /// <param name="discardPile">discard pile </param>
        /// <param name="drawPile">draw card pile</param>
        public static void StartGame(Hand userHand, Hand computerHand, CardPile discardPile, CardPile drawPile)
        {
            IsPlaying = true;
            IsUserTurn = true;
            UserHand = userHand;
            ComputerHand = computerHand;
            _discardPile = discardPile;
            _drawPile = drawPile;
        }
        /// <summary>
        /// set a method that could check the hand if there is a card enable to be played 
        /// </summary>
        /// <param name="hand">which hand will be checked</param>
        /// <returns></returns>
        private static bool IsHandPlayable(Hand hand)
        {
            foreach (Card card in hand)
            {
                if (IsCardPlayable(card) == true)
                {
                    return true;
                }
            }
            return false;
        }


        /// <summary>
        /// set a method that could check the card if it can be played
        /// </summary>
        /// <param name="card">which card will be checked  </param>
        /// <returns></returns>
        private static bool IsCardPlayable(Card card)
        {
            if ((card.FaceValue == TopDiscard.FaceValue) || (card.Suit == TopDiscard.Suit)||(card.FaceValue.ToString() == "Eight"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// set a method that contains all logics when user draw a card 
        /// </summary>
        /// <returns></returns>
        public static ActionResult UserDrawCard()
        {
            if (IsPlaying == false)
            {
                throw new Exception();
            }
            else if (IsUserTurn == false)
            {
                throw new Exception();
            }
            // the situation that flip the deck
            else if (IsDrawPileEmpty)
            {   
                for (int number = 0; number < _discardPile.Count;)
                {
                    _drawPile.AddCard(_discardPile.DealOneCard());
                }
                _discardPile.AddCard(_drawPile.DealOneCard());
                return ActionResult.FlippedDeck;
            }
            // the situation that user cannot draw a card
            else if (IsHandPlayable(UserHand) || TopDiscard.FaceValue.ToString() == "Eight")
            {
                return ActionResult.CannotDraw;
            }
            // the situation that user draw a playable card
            else
            {
                Card card = _drawPile.DealOneCard();
                UserHand.AddCard(card);
                if (IsCardPlayable(card))
                {
                    return ActionResult.DrewPlayableCard;
                }
                //the situation that user's hand is full
                else if (!IsCardPlayable(card))
                {
                    // the situation that both user's hand and computer's hand is full and cannot play any card
                    if (UserHand.Count == FullHandCardNum && ComputerHand.Count == FullHandCardNum)
                    {
                        for (int number = 1; number <= _discardPile.Count;)
                        {
                        _drawPile.AddCard(_discardPile.DealOneCard());
                        }
                        _drawPile.ShufflePile(_drawPile.Count);
                        _discardPile.AddCard(_drawPile.DealOneCard());
                        IsUserTurn = false;
                        return ActionResult.DrewAndResetPiles;
                    }
                    // the situation that jump to computer's turn
                    else if (UserHand.Count == FullHandCardNum)
                    {
                        IsUserTurn = false;
                        
                        return ActionResult.DrewAndNoMovePossible;
                    }
                    // the situation that user continue draw cards
                    else
                    {
                        return ActionResult.DrewUnplayableCard;
                    }
                }
            }
            return ActionResult.CannotDraw;
        }
        /// <summary>
        /// the method that contains all logics when user plays cards
        /// </summary>
        /// <param name="cardNum">which card will be played </param>
        /// <param name="chosenSuit">if user play a card with facevalue "Eight"
        /// user can change the suit</param>
        /// <returns>return the action result </returns>
        public static ActionResult UserPlayCard(int cardNum, Suit? chosenSuit = null)
        {
            

            if (IsPlaying == false)
            {
                throw new Exception();
            }
            else if (IsUserTurn == false)
            {
                throw new Exception();
            }
            //the situation that user has an "Eight"
            else if ((UserHand.GetCard(cardNum)).FaceValue.ToString() == "Eight")
            {
                if (chosenSuit != null)
                {
                    IsUserTurn = false;
                    Card card = new Card((Suit)chosenSuit, FaceValue.Eight);
                    _discardPile.AddCard(card);
                    UserHand.RemoveCardAt(cardNum);
                    return ActionResult.ValidPlay;
                }
                else
                {
                    return ActionResult.SuitRequired;
                }
            }
            //the situation that user wins the game
            else if (UserHand.Count == 1 && IsCardPlayable(UserHand.GetCard(0)))
            {
                _discardPile.AddCard(UserHand.GetCard(0));
                UserHand.RemoveCard(UserHand.GetCard(0));
                IsUserTurn = false;
                IsPlaying = false;
                return ActionResult.WinningPlay;
            }
            //the situation that the top card in discard pile is an "Eight"
            else if (TopDiscard.FaceValue.ToString() == "Eight")
            {
                _discardPile.AddCard(UserHand.GetCard(cardNum));
                UserHand.RemoveCardAt(cardNum);
                IsUserTurn = false;
                return ActionResult.ValidPlay;
            }
            //user continue drawing cards
            else if (!IsHandPlayable(UserHand))
            {
                return ActionResult.InvalidPlayAndMustDraw;
            }
            else if (IsHandPlayable(UserHand) && !IsCardPlayable(UserHand.GetCard(cardNum))) {
                return ActionResult.InvalidPlay;
            }
            //the situation that user could get an extra turn
            else if (IsCardPlayable(UserHand.GetCard(cardNum)))
            {
                if (!IsHandPlayable(ComputerHand) && ComputerHand.Count == FullHandCardNum) {
                    _discardPile.AddCard(UserHand.GetCard(cardNum));
                    UserHand.RemoveCardAt(cardNum);
                    IsUserTurn = true;
                    return ActionResult.ValidPlayAndExtraTurn;
                }
                else
                {
                    _discardPile.AddCard(UserHand.GetCard(cardNum));
                    UserHand.RemoveCardAt(cardNum);
                    IsUserTurn = false;

                    return ActionResult.ValidPlay;
                }
            }
            //user plays a card
            else if (IsHandPlayable(UserHand) && IsHandPlayable(ComputerHand))
            {
                _discardPile.AddCard(UserHand.GetCard(cardNum));
                UserHand.RemoveCardAt(cardNum);
                IsUserTurn = false;
                return ActionResult.ValidPlay;
            }


            //user's hand is not full and don't have a playable card
            else if (UserHand.Count != FullHandCardNum && !IsHandPlayable(UserHand))
            {
                return ActionResult.InvalidPlayAndMustDraw;
            }
          
            return ActionResult.InvalidPlay;            
        }
        /// <summary>
        /// this method is used to check which specific card in computer's hand 
        /// could be played 
        /// </summary>
        /// <returns>if the result > 0, it means computer can play cards.
        /// if result = 0, it means the topcard in discard pile is Eight, computer can play cards
        /// if result = Empty, it means computer can't play cards.  </returns>
        public static int ComputerCardIndex()
        {
            int result = Empty;
            for (int number = 0; number < ComputerHand.Count; number++)
            {
                 if ((ComputerHand.GetCard(number).FaceValue).ToString() == "Eight")
                {
                    result = number;
                }
            }
            for (int number = 0; number < ComputerHand.Count; number++)
            {
                if (ComputerHand.GetCard(number).Suit == TopDiscard.Suit)
                {
                    result = number;
                }
            }
            for (int number = 0; number < ComputerHand.Count; number++)
            {
                if ( ComputerHand.GetCard(number).FaceValue == TopDiscard.FaceValue)
                {
                    result = number;
                }
            }
            if (TopDiscard.FaceValue.ToString() == "Eight")
            {
                result = 0;
            }
            return result;
        }
        /// <summary>
        /// the method that contains all computer's playing logic
        /// </summary>
        /// <returns></returns>
        public static ActionResult ComputerAction()
        {
            if (IsPlaying == false)
            {
                throw new Exception();
            }
            else if (IsUserTurn == true)
            {
                throw new Exception();
            }
            else {
                // if there is a card in computer's hand that can be played
                int CardNum = ComputerCardIndex();
                if (CardNum >= 0) {
                    //judge if computer is winning first
                    if (ComputerHand.Count == 1)
                    {
                        _discardPile.AddCard(ComputerHand.GetCard(CardNum));
                        ComputerHand.RemoveCardAt(CardNum);
                        IsPlaying = false;
                        return ActionResult.WinningPlay;
                    }
                    //judge if user can have an extra turn
                    else if (!IsHandPlayable(ComputerHand) && ComputerHand.Count == FullHandCardNum)
                    {
                        IsUserTurn = true;
                        return ActionResult.ForcelyEnd;
                    }
                    // judge if computer can get an extra turn and it's actions
                    else if (!IsHandPlayable(UserHand) && UserHand.Count == FullHandCardNum)
                    {
                        _discardPile.AddCard(ComputerHand.GetCard(CardNum));
                        ComputerHand.RemoveCardAt(CardNum);
                        if (!IsHandPlayable(UserHand))
                        {
                            IsUserTurn = false;
                            return ActionResult.ValidPlayAndExtraTurn;
                        }
                        IsUserTurn = true;
                        return ActionResult.ValidPlay;
                    }
                    // the situation that the top card in discard pile is eight
                    else if (TopDiscard.FaceValue.ToString() == "Eight")
                    {
                        _discardPile.AddCard(ComputerHand.GetCard(0));
                        ComputerHand.RemoveCardAt(0);
                        IsUserTurn = true;
                        return ActionResult.ValidPlay;
                    }
                    else
                    {
                        _discardPile.AddCard(ComputerHand.GetCard(CardNum));
                        ComputerHand.RemoveCardAt(CardNum);
                        IsUserTurn = true;
                        return ActionResult.ValidPlay;
                    }
                }
                // if there is no card in computer's hand that can be played
                else if (CardNum == Empty)
                {
                    // the result that computer draw cards
                    if (!IsDrawPileEmpty)
                    {
                        Card card = (_drawPile.DealOneCard());
                        ComputerHand.AddCard(card);
                         if (IsCardPlayable(card)){
                            IsUserTurn = false;
                            return ActionResult.DrewPlayableCard;
                        }
                        // the situation that computer's hand is full
                        else if (ComputerHand.Count == FullHandCardNum)
                        {
                            // the situation that drew and reset piles
                            if (UserHand.Count == FullHandCardNum && !IsCardPlayable(card))
                            {
                                for (int number = 1; number <= _discardPile.Count;)
                                {
                                    _drawPile.AddCard(_discardPile.DealOneCard());
                                }
                                _drawPile.ShufflePile(_drawPile.Count);
                                _discardPile.AddCard(_drawPile.DealOneCard());
                                IsUserTurn = true;
                                return ActionResult.DrewAndResetPiles;
                            }
                            //the situation that jump to user's turn
                            else if (!IsCardPlayable(card))
                            {
                                IsUserTurn = true;
                                return ActionResult.DrewAndNoMovePossible;
                            }
                        }
                        // the situation that drew a unplayable card and continue computer's turn
                        else
                        {
                            IsUserTurn = false;
                            return ActionResult.DrewUnplayableCard;
                        }
                    }
                    // the situation that flip the deck
                    else if (IsDrawPileEmpty)
                    {
                        for (int number = 0; number < _discardPile.Count;)
                        {
                            _drawPile.AddCard(_discardPile.DealOneCard());
                        }
                        _discardPile.AddCard(_drawPile.DealOneCard());
                        IsUserTurn = false;
                        return ActionResult.FlippedDeck;
                    }
                }               
                return ActionResult.ValidPlay;
            }
            
        }
        /// <summary>
        /// the method that end the game
        /// </summary>        public static void EndGame()
        {
            IsPlaying = false;
        }
    }
}
